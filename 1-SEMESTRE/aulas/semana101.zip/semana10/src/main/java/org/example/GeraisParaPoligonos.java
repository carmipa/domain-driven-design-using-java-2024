package org.example;

public interface GeraisParaPoligonos {

    double getArea();
}
