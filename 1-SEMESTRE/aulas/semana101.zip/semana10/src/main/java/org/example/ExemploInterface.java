package org.example;

public interface ExemploInterface {
}
