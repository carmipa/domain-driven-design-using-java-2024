package org.example;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        //classes abstratas nao podem ser instanciadas
//        MinimoPoligono minimoPoligono = new MinimoPoligono(2,2,2);

        Triangulo triangulo = new Triangulo(3,3,3);
        triangulo.getTipo();
        triangulo.getArea();

        MinimoPoligono minimoPoligono1 = new Triangulo(2,2,2);

        Quadrilatero quadrilatero = new Quadrilatero(2,2,2,2);

        Pentagono pentagono = new Pentagono(2,2,2,2,2);
        pentagono.getArea();

        Hexagono hexagono = new Hexagono(2,2,2,2,2,2);

    //  nao é possivel criar uma instancia de uma interface
    //  GeraisParaPoligonos geraisParaPoligonos = new GeraisParaPoligonos();

        GeraisParaPoligonos geraisParaPoligonos = new Quadrilatero(2,2,2,2);
        geraisParaPoligonos.getArea();


        // exemplo exclusivo para demonstrar um dos usos de polimorfismo - vamos abordar collections no semestre que vem
        List<MinimoPoligono> listaPoligonos = List.of(triangulo, quadrilatero, pentagono,hexagono);

        for (MinimoPoligono poligono : listaPoligonos) {
            poligono.getArea();
        }
    }
}